from datetime import datetime
from app import db

class Dog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    breed = db.Column(db.String(100), nullable=False)
    gender = db.Column(db.String(20), nullable=False)  # 'Male' or 'Female'
    birth_date = db.Column(db.Date, nullable=True)
    registration_number = db.Column(db.String(50), unique=True, nullable=True)
    microchip_number = db.Column(db.String(50), unique=True, nullable=True)
    sire_id = db.Column(db.Integer, db.ForeignKey('dog.id'), nullable=True)
    dam_id = db.Column(db.Integer, db.ForeignKey('dog.id'), nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    notes = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    sire = db.relationship('Dog', remote_side=[id], backref='offspring_as_sire', foreign_keys=[sire_id])
    dam = db.relationship('Dog', remote_side=[id], backref='offspring_as_dam', foreign_keys=[dam_id])
    pregnancies = db.relationship('Pregnancy', backref='dog', lazy=True)
    heat_cycles = db.relationship('HeatCycle', backref='dog', lazy=True)
    locations = db.relationship('Location', backref='dog', lazy=True)

    def __repr__(self):
        return f'<Dog {self.name}>'

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'breed': self.breed,
            'gender': self.gender,
            'birth_date': self.birth_date.strftime('%Y-%m-%d') if self.birth_date else None,
            'registration_number': self.registration_number,
            'microchip_number': self.microchip_number,
            'sire_id': self.sire_id,
            'dam_id': self.dam_id,
            'is_active': self.is_active,
            'notes': self.notes,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            'updated_at': self.updated_at.strftime('%Y-%m-%d %H:%M:%S')
        }


class Pregnancy(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    dog_id = db.Column(db.Integer, db.ForeignKey('dog.id'), nullable=False)
    sire_id = db.Column(db.Integer, db.ForeignKey('dog.id'), nullable=True)
    start_date = db.Column(db.Date, nullable=False)
    expected_due_date = db.Column(db.Date, nullable=True)
    actual_due_date = db.Column(db.Date, nullable=True)
    litter_size = db.Column(db.Integer, nullable=True)
    males_count = db.Column(db.Integer, nullable=True)
    females_count = db.Column(db.Integer, nullable=True)
    status = db.Column(db.String(50), default='Active')  # Active, Completed, Terminated
    notes = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationship with sire
    sire = db.relationship('Dog', foreign_keys=[sire_id])

    def __repr__(self):
        return f'<Pregnancy {self.id} - Dog {self.dog_id}>'

    def to_dict(self):
        return {
            'id': self.id,
            'dog_id': self.dog_id,
            'sire_id': self.sire_id,
            'start_date': self.start_date.strftime('%Y-%m-%d'),
            'expected_due_date': self.expected_due_date.strftime('%Y-%m-%d') if self.expected_due_date else None,
            'actual_due_date': self.actual_due_date.strftime('%Y-%m-%d') if self.actual_due_date else None,
            'litter_size': self.litter_size,
            'males_count': self.males_count,
            'females_count': self.females_count,
            'status': self.status,
            'notes': self.notes,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            'updated_at': self.updated_at.strftime('%Y-%m-%d %H:%M:%S')
        }


class HeatCycle(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    dog_id = db.Column(db.Integer, db.ForeignKey('dog.id'), nullable=False)
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=True)
    intensity = db.Column(db.String(20), nullable=True)  # Mild, Moderate, Severe
    notes = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f'<HeatCycle {self.id} - Dog {self.dog_id}>'

    def to_dict(self):
        return {
            'id': self.id,
            'dog_id': self.dog_id,
            'start_date': self.start_date.strftime('%Y-%m-%d'),
            'end_date': self.end_date.strftime('%Y-%m-%d') if self.end_date else None,
            'intensity': self.intensity,
            'notes': self.notes,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            'updated_at': self.updated_at.strftime('%Y-%m-%d %H:%M:%S')
        }


class Location(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    dog_id = db.Column(db.Integer, db.ForeignKey('dog.id'), nullable=False)
    location_name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=True)
    is_current = db.Column(db.Boolean, default=True)
    notes = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f'<Location {self.id} - Dog {self.dog_id}>'

    def to_dict(self):
        return {
            'id': self.id,
            'dog_id': self.dog_id,
            'location_name': self.location_name,
            'description': self.description,
            'start_date': self.start_date.strftime('%Y-%m-%d'),
            'end_date': self.end_date.strftime('%Y-%m-%d') if self.end_date else None,
            'is_current': self.is_current,
            'notes': self.notes,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            'updated_at': self.updated_at.strftime('%Y-%m-%d %H:%M:%S')
        }
